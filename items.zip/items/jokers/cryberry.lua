local jokerInfo = {
	name = 'Cryberries [WIP]',
	config = {},
	rarity = 1,
	cost = 0,
	blueprint_compat = false,
	eternal_compat = true,
	perishable_compat = true,
	streamer = "vinny",
}

function jokerInfo.calculate(self, card, context)
	--todo
end

return jokerInfo
	